import React, { Component } from 'react'

export class Add extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         first_name:'',last_name:'',email:''
      }
    }
    changeHandler=(e)=>{
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    fetch_submit()
    {
        fetch('http://localhost:3001/Posts',
        {method:'POST',
    headers:{
        Accept:'application/json',
        'Content-Type':'application/json'
    },
    body:JSON.stringify(this.state)})
    .then(res=>{
        if(res.status==201)
        {
            alert('User Record Saved Successfully!')
            window.location="./"
        }
        else{
            alert('Something Went Wrong!')
        }       
    })
    .catch(err=>{
        console.log(err)
    })
    }

    xhr_submit()
    {
        alert('1')
       var xhr=new XMLHttpRequest();
       xhr.open("POST","http://localhost:3001/Posts")
       xhr.setRequestHeader("Content-Type","application/json")
       xhr.onreadystatechange=()=>{
          if(xhr.status==201)
          {
            alert('Record saved Successfully')
            window.location="./"
          }        
       }
       xhr.onerror=(err)=>{
            console.log(err)
       }
       xhr.send(JSON.stringify(this.state))
    }
    submitHandler=(e)=>{
        e.preventDefault()
        //console.log(this.state)
        //fetch('https://reqres.in/api/users',
       this.xhr_submit();
    }
  render() {
    const {first_name,last_name,email}=this.state
    return (
      <div>
        <div className='container mt-5 p-3'>
            <form onSubmit={this.submitHandler}>
                <div className='alert alert-success'>Add User</div>
                <div className='row mt-5'>
                    <div className='col'>
                        <input type='text' className='form-control' placeholder='Enter First Name'
                        name="first_name" value={first_name} onChange={this.changeHandler}/>
                    </div>
                    <div className='col'>
                        <input type='text' className='form-control' placeholder='Enter Last Name'
                        name="last_name" value={last_name} onChange={this.changeHandler}/>
                    </div>
                </div>
                <div className='row mt-5'>
                <div className='col'>
                        <input type='text' className='form-control' placeholder='Enter E-Mail'
                        name="email" value={email} onChange={this.changeHandler}/>
                    </div>
                </div>
                <div className='row mt-5'>
                <div className='col'>
                        <button type="submit" className='btn btn-success'>Add User</button>
                    </div>
                </div>
            </form>
        </div>
      </div>
    )
  }
}

export default Add