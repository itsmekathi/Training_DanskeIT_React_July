import React from 'react'
import { useParams } from 'react-router-dom'

function Delete() {
  const {id}=useParams()
  fetch('http://localhost:3001/Posts/'+id,
  {method:'DELETE',headers:{Accept:'application/json','content-type':'application/json'}})
  .then(result=>{
  
    if(result.status==200)
    {
        alert('Product Deleted Successfully!')
    }
    else{
        alert('Something Went Wrong!')
    }
    window.location='../'
  })
  
  return (
    <div>Delete</div>
  )
}

export default Delete