import React, { Component } from 'react'
import { Link } from 'react-router-dom'

export class Home extends Component {
    constructor(props) {
      super(props)    
      this.state = {
         users:[]
      }
    }
    fetch_getdata()
    {
      fetch('http://localhost:3001/Posts',{method:'GET'})
      .then(result=>{return result.json()})
      .then(res=>{
          //console.log(res.data)
          this.setState({users:res})
      })
    }
    xhr_getdata()
    {
        var xhr=new XMLHttpRequest()
        xhr.open('GET','http://localhost:3001/Posts')
        xhr.setRequestHeader("Content-Type","application/json")
        xhr.onload=()=>{
          if(xhr.status==200)
          {
            this.setState({users:JSON.parse(xhr.responseText)})
          }
        }
        xhr.send()
    }
    componentDidMount()
    {        
        //this.fetch_getdata();
        this.xhr_getdata()
    }
  render() {
    const {users}=this.state
    return (
      <div>
        <div className='container mt-3'>
          <Link to={`/Add`} className='btn btn-success'>Add User</Link>
        </div>
        <div className='container mt-3'>
            <table className='table table-responsive table-bordered table-hover'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.length?
                        users.map((x,i)=>
                        <tr key={i}>
                            <td>{x.id}</td>
                            <td>{x.first_name} {x.last_name}</td>
                            <td>{x.email}</td>
                            <td>
                                <Link to={`/Edit/${x.id}`} className='btn btn-warning'>Edit</Link>
                                &nbsp;
                                <Link to={`/Delete/${x.id}`} className='btn btn-danger'>Delete</Link>
                            </td>
                        </tr>
                        )
                        :null
                    }
                </tbody>
            </table>
        </div>
      </div>
    )
  }
}

export default Home