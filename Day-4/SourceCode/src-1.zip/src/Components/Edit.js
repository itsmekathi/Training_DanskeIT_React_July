import React, { Component } from 'react'

export class Edit extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         id:0,first_name:'',last_name:'',email:''
      }
    }
    changeHandler=(e)=>{
        this.setState({
            [e.target.name]:e.target.value
        })
    }

    componentDidMount()
    {
        const _id=window.location.pathname.split('/')[2]
        fetch('http://localhost:3001/Posts/'+_id)
        .then(result=>{return result.json()})
        .then(res=>{ 
            console.log(res)           
            this.setState({
                id:res['id'],
                first_name:res['first_name'],
                last_name:res['last_name'],
                email:res['email'],
            })
        })
    }

    submitHandler=(e)=>{
        e.preventDefault()
        //console.log(this.state)
        fetch('http://localhost:3001/Posts/'+this.state.id,
        {method:'PUT',
    headers:{
        Accept:'application/json',
        'Content-Type':'application/json'
    },
    body:JSON.stringify(this.state)})
    .then(res=>{
        if(res.status==200)
        {
            alert('User Record Updated Successfully!')
            window.location="../"
        }
        else{
            alert('Something Went Wrong!')
        }       
    })
    .catch(err=>{
        console.log(err)
    })
    }
  render() {
    const {first_name,last_name,email}=this.state
    return (
      <div>
        <div className='container mt-5 p-3'>
            <form onSubmit={this.submitHandler}>
                <div className='alert alert-success'>Edit User</div>
                <div className='row mt-5'>
                    <div className='col'>
                        <input type='text' className='form-control' placeholder='Enter First Name'
                        name="first_name" value={first_name} onChange={this.changeHandler}/>
                    </div>
                    <div className='col'>
                        <input type='text' className='form-control' placeholder='Enter Last Name'
                        name="last_name" value={last_name} onChange={this.changeHandler}/>
                    </div>
                </div>
                <div className='row mt-5'>
                <div className='col'>
                        <input type='text' className='form-control' placeholder='Enter E-Mail'
                        name="email" value={email} onChange={this.changeHandler}/>
                    </div>
                </div>
                <div className='row mt-5'>
                <div className='col'>
                        <button type="submit" className='btn btn-success'>Update User</button>
                    </div>
                </div>
            </form>
        </div>
      </div>
    )
  }
}

export default Edit