import logo from './logo.svg';
import './App.css';
import Demo from './Components/FunctionalHooks/Demo';
import DemoCounter from './Components/FunctionalHooks/DemoCounter';
import UseEffectSample from './Components/FunctionalHooks/UseEffectSample';
import ComponentA from './Components/ContextAPIDemo/ComponentA';
import { UserProvider } from './Components/ContextAPIDemo/UserContext';

function App() {
  return (
    <div>
      <UserProvider value="admin698">
          <ComponentA/>
      </UserProvider>
    </div>
  );
}

export default App;
