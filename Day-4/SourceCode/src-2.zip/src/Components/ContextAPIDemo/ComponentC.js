import React, { Component } from 'react'
import { UserConsumer } from './UserContext'

export class ComponentC extends Component {
  render() {
    return (
      <div>
        ComponentC
        <UserConsumer>
            {
                (inp)=>{
                    return <h1>{inp}</h1>
                }
            }
        </UserConsumer>
      </div>
    )
  }
}

export default ComponentC