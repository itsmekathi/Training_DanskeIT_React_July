import React,{useState,useEffect} from 'react'

function UseEffectSample() {
    const[count,setCount]=useState(0)
    const[name,setName]=useState('')
    function clickHandler()
    {
        setCount(count+1)
    }

    useEffect(()=>{
        console.log('Use Effect Invoked')
    },[name])
    
  return (
    <div>
        <h1>{count}</h1>
        <button onClick={()=>clickHandler()}>Increment</button>
    </div>
  )
}

export default UseEffectSample