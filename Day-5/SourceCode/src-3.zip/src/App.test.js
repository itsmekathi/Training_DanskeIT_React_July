import { render, screen,fireEvent } from '@testing-library/react';
import App from './App';
import Demo from './Components/Demo';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});

test('checking word Demo',()=>{
  render(<Demo/>)
  expect(screen.getByText('Demo')).toBeInTheDocument();
})


test('Props Demo-1',()=>{
  const name="Raj Kumar"
  render(<Demo name={name}/>)
  expect(screen.getByText(name)).toBeInTheDocument();
})

test('Check Defualt Count',()=>{
  render(<Demo/>)
  expect(screen.getByText('Count:0')).toBeInTheDocument()
})

test('Check Counter',()=>{
  render(<Demo/>)
  const btn=screen.getByRole('button')
  fireEvent.click(btn)
  fireEvent.click(btn)
  fireEvent.click(btn)
  expect(screen.getByText('Count:1')).toBeInTheDocument()
})