import React,{useState} from 'react'

function Demo(props) {
    const[count,setCount]=useState(0)
    function clickHandler()
    {
        setCount(count+1)
    }
  return (
    <div>
        Demo
        <h1>{props.name}</h1>
        <h2>Count:{count}</h2>
        <button onClick={clickHandler}>Increment</button>
    </div>
  )
}

export default Demo