import React from 'react'

const HOC=(Component)=> {
  return (
    class extends React.Component{
        state={isauthenticated:false}
        render(){
            return(
                <div>
                    {
                        this.state.isauthenticated
                        ?<Component/>
                        :<h1>You are not allowed to view this page!</h1>
                    }
                </div>
            )
        }
    }
  )
}

export default HOC