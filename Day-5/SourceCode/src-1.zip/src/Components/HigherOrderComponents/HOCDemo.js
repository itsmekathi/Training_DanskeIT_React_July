import React from 'react'
import HOC from './HOC'

function HOCDemo() {
  return (
    <div>HOCDemo</div>
  )
}

export default HOC(HOCDemo)