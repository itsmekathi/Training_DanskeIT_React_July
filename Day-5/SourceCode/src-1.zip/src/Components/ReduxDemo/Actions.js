export const IncAction=(value)=>async dispatch=>{
   dispatch({type:'increment',payload:value})
}

export const DecAction=(value)=>async dispatch=>{
    dispatch({type:'decrement',payload:value})
}