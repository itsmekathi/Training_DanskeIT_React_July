import React from 'react'
import {connect} from 'react-redux'
import { IncAction,DecAction } from './Actions'

function ReduxDemoConponent({count,IncAction,DecAction}) 
{
  return (
    <div>
        <h1>{count}</h1>
        <button onClick={()=>DecAction(5)}>Decrement</button>
        <button onClick={()=>IncAction(5)}>Increment</button>
    </div>
  )
}
const mapStateToProps=state=>( 
    {count:state}
)
export default connect(mapStateToProps,{ IncAction,DecAction })(ReduxDemoConponent)