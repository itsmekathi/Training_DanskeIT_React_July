import logo from './logo.svg';
import './App.css';
import HOCDemo from './Components/HigherOrderComponents/HOCDemo';
import ReduxDemoConponent from './Components/ReduxDemo/ReduxDemoConponent';
import { Provider } from 'react-redux';
import Store from './Components/ReduxDemo/Store';

function App() {
  return (
    <div className="App">
      {/* <HOCDemo/> */}
      <Provider store={Store}>
          <ReduxDemoConponent/>
      </Provider>
        
    </div>
  );
}

export default App;
