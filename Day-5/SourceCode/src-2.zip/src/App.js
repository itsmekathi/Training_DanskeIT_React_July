import logo from './logo.svg';
import './App.css';
import ProductComponent from './Components/ReduxDemo/ProductComponent';
import {Provider} from 'react-redux'
import { Store } from './Redux/Store';
import NavBar from './Components/ReduxDemo/NavBar';
import React,{lazy,useState,useEffect,Suspense} from 'react'
import Demo from './Components/AXIOS_/Demo';

const LazyComponent=lazy(()=>import('./Components/LazyLoading/LazyLoadingDemo'))

function App() {
  const[showLoader,setShowLoader]=useState(true)
  useEffect(()=>{
    const delay=setTimeout(()=>{
      setShowLoader(false)
    },5000)
    return ()=>clearTimeout(delay)
  },[])

  return (
    <div>
     {/* <Suspense fallback={<div>Loading.....</div>}>
      {
        showLoader?
        (<div>
          Loading....
        </div>):
        <LazyComponent/>
      }
     </Suspense> */}
     <Demo/>
     
    </div>
  );
}

export default App;
