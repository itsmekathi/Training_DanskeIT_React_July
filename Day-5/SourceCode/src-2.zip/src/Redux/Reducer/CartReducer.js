import { createSlice } from "@reduxjs/toolkit";

const initialState={
    cartValues:[]
}

const CartReducer=createSlice({
    name:'CartReducer',initialState,
    reducers:{
        addToCart:(state,action)=>{
            state.cartValues.push(action.payload)
            const pricesArr=state.cartValues.map(x=>x.productPrice)
            state.totalPrice=pricesArr.reduce((a,b)=>a+b)
        },
        removeFromCart:(state,action)=>{
            const index=state.cartValues.findIndex(x=>x.productName===action.payload.productName)
            if(index>-1)
            {
                state.cartValues.splice(index,1)
            }
            if(state.cartValues.length!=0)
            {
                const pricesArr=state.cartValues.map(x=>x.productPrice)
                state.totalPrice=pricesArr.reduce((a,b)=>a+b)
            }
            else{
                state.totalPrice=0
            }
        }
    }
})
export const {addToCart,removeFromCart}=CartReducer.actions
export default CartReducer.reducer