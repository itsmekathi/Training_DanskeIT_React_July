import React from 'react'

function LazyLoadingDemo() {
  return (
    <div>LazyLoadingDemo</div>
  )
}

export default LazyLoadingDemo