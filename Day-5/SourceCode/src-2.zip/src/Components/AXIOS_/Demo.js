import React, { Component } from 'react'
import axios from 'axios'

export class Demo extends Component {
    componentDidMount()
    {
        // axios.get('https://reqres.in/api/users?page=2')
        // .then(res=>{
        //     console.log(res.data.data)
        // })
        axios.post('/api/users',{email:'test',first_name:'',last_name:''})
        .then(res=>{
            console.log(res)
        })
    }
  render() {
    return (
      <div>Demo</div>
    )
  }
}

export default Demo