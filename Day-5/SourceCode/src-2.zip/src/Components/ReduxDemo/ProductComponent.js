import React from 'react'
import ProductsData from '../../Data/ProductsData.json'
import {useDispatch} from 'react-redux'
import { addToCart, removeFromCart } from '../../Redux/Reducer/CartReducer'

const ProductComponent=()=> {
    const dispatch=useDispatch()
  return (
    <div>
        <div className='container mt-5'>
            <div className='row'>
                {
                    ProductsData.Products.map((x,i)=>
                       <div className='col' key={i}>
                         <div className='card'>
                            <img className='card-img-top' src="https://cdn-icons-png.flaticon.com/128/2777/2777142.png"/>
                            <p className='card-title'>
                                {x.Name} | {x.Price}
                            </p>
                            <div className='card-body mt-2'>
                            <button className='btn btn-primary' 
                            onClick={()=>dispatch(addToCart({productName:x.Name,productPrice:x.Price}))}>Add</button>
                            &nbsp;
                            <button className='btn btn-primary' 
                            onClick={()=>dispatch(removeFromCart({productName:x.Name,productPrice:x.Price}))}>Remove</button>
                             </div>
                         </div>
                         
                    </div>
                    )
                }
            </div>
        </div>
    </div>
  )
}

export default ProductComponent