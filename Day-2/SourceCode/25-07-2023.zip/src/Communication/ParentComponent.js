import React, { Component } from 'react'
import ChildComponent from './ChildComponent'

export class ParentComponent extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'Parent'
      }
      this.greet=this.greet.bind(this)
    }
    greet()
    {
        alert(`Hello,${this.state.name}`)
    }
  render() {
    return (
      <div>
        <ChildComponent handler={this.greet}/>
      </div>
    )
  }
}

export default ParentComponent