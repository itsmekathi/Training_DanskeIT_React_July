import React from 'react'

function Login() {
    let isloggedin=false
    if(isloggedin)
    {
        return (
            <div>Admin</div>
        )
    }
    else{
        return (
            <div>Guest</div>
          )
    }
}

export default Login