import React, { Component } from 'react'

export class Login4 extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         isloggedinn:false
      }
    }
  render() {
    return (
      this.state.isloggedinn &&
      <div>
        <h1>Welcome 'Admin'</h1>
      </div>      
    )
  }
}

export default Login4