import React, { Component } from 'react'

export class Login1 extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         isLoggedin:false
      }
    }
  render() {
    if(this.state.isLoggedin)
    {
        return(
            <div>Welcome Admin</div>
        )
    }
    else{
        return(
            <div>Welcome Guest</div>
        )
    }
  }
}

export default Login1