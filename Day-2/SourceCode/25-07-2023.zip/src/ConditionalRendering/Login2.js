import React, { Component } from 'react'

export class Login2 extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         isLoggedin:false
      }
    }
  render() {
    let user
    if(this.state.isLoggedin)
    {
        user="Admin"
    }
    else
    {
        user="guest"
    }
    return(
        <div>
            Welcome,{user}
        </div>
    )
  }
}

export default Login2