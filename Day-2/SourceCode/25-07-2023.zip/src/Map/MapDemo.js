import React from 'react'


function MapDemo() {
    const courses=['C','C++','SQL','Angular','React']
  return (
    <div>
        <ol>
            {
                courses.map((course,i)=>
                    <li key={i}>{course}</li>)
            }
        </ol>
    </div>
  )
}

export default MapDemo