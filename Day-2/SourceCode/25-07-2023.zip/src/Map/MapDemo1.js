import React from 'react'

function MapDemo1() {
    const products=[
        {id:101,name:'Iphone 14',price:69000},
        {id:102,name:'Iphone 14 Pro',price:98500},
        {id:103,name:'Samsung S23FE',price:90000},
        {id:104,name:'Dell Latitude 3525',price:62500},
        {id:105,name:'Lenovo P51E',price:39800}
    ]
  return (
    <div>
        <table className='table table-bordered table-responsive table-hover'>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                {
                    products.map((prod,i)=>
                    <tr key={i}>
                        <td>{prod.id}</td>
                        <td>{prod.name}</td>
                        <td>{prod.price}</td>
                    </tr>)
                }
            </tbody>
        </table>
    </div>
  )
}

export default MapDemo1