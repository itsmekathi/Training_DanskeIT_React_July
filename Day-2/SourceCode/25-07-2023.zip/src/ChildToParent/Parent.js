import React from 'react'
import Child from './Child'

function printmsg(msg,username){
    return(
        <div>
            <h1>Message Received:{msg}</h1>
            <h2>From:{username}</h2>
        </div>
    )
}
function Parent() {
  return (
    <div>
        <Child handler={printmsg}/>
    </div>
  )
}

export default Parent