import React from 'react'

function Child(props) {
  return (
    <div>
        {props.handler('Hello World!','Krishna')}
    </div>
  )
}

export default Child