import logo from './logo.svg';
import './App.css';
import Demo from './Basics/Demo';
import ParentComponent from './Communication/ParentComponent';
import Parent from './ChildToParent/Parent';
import Login1 from './ConditionalRendering/Login1';
import Login from './ConditionalRendering/Login';
import Login2 from './ConditionalRendering/Login2';
import Login3 from './ConditionalRendering/Login3';
import Login4 from './ConditionalRendering/Login4';
import MapDemo from './Map/MapDemo';
import MapDemo1 from './Map/MapDemo1';
import MyStyles from './CSSStyles/MyStyles';
import InlineStyling from './CSSStyles/InlineStyling';
import TestComponent from './CSSStyles/TestComponent';
import ContactForm from './BasicForm/ContactForm';
import FormComponent from './BasicForm/FormComponent';

function App() {
  return (
  //  <Demo/>
  // <ParentComponent/>
  // <Parent/>
  // <Login1/>
  // <Login/>
  // <Login2/>
  // <Login3/>
  // <Login4/>
  // <MapDemo/>
  // <MapDemo1/>
  // <MyStyles status={false} />
  // <InlineStyling/>
  // <TestComponent/>
  // <ContactForm/>
  <FormComponent/>
  );
}

export default App;
