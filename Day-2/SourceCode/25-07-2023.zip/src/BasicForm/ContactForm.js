import React, { Component } from 'react'

export class ContactForm extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'',
         mobile:'',
         city:''
      }
    }
    changeNameHandler=(event)=>
    {
        this.setState({name:event.target.value})
    }

    changeMobileHandler=(event)=>
    {
        this.setState({mobile:event.target.value})
    }

    changeCityHandler=(event)=>
    {
        this.setState({city:event.target.value})
    }

    submitHandler=(event)=>
    {
        event.preventDefault();
        console.log(this.state)
    }

  render() {
    return (
      <div>
        <form onSubmit={this.submitHandler}> 
        Name:
        <input type='text' defaultValue={this.state.name} onChange={this.changeNameHandler}/>
        <br/>
        Mobile:
        <input type='text' defaultValue={this.state.mobile} onChange={this.changeMobileHandler}/>
        <br/>
        City:
        <select defaultValue={this.state.city} onChange={this.changeCityHandler}>
            <option value="">--select--</option>
            <option value="MUM">Mumbai</option>
            <option value="CHN">Chennai</option>
            <option value="DEL">Delhi</option>
            <option value="PUN">Pune</option>
        </select>
        <br/>
        <button type="submit">Submit</button>
        </form>
      </div>
    )
  }
}

export default ContactForm