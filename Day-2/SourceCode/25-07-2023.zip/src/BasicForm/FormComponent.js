import React, { Component } from 'react'

export class FormComponent extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         user:[]
      }
    }
    changeHandler=(e)=>{
         this.setState((prevState)=>({
            user:
            {...prevState.user,
            [e.target.name]:e.target.value
            }
         }))
    }
    submitHandler=(e)=>{
        e.preventDefault()
        console.log(this.state.user)
    }
  render() {
    return (
      <div>
         <form onSubmit={this.submitHandler}> 
        Name:
        <input type='text' name="name" onChange={this.changeHandler}/>
        <br/>
        Mobile:
        <input type='text' name="mobile" onChange={this.changeHandler}/>
        <br/>
        City:
        <select name="city" onChange={this.changeHandler}>
            <option value="">--select--</option>
            <option value="MUM">Mumbai</option>
            <option value="CHN">Chennai</option>
            <option value="DEL">Delhi</option>
            <option value="PUN">Pune</option>
        </select>
        <br/>
        <button type="submit">Submit</button>
        </form>
      </div>
    )
  }
}

export default FormComponent