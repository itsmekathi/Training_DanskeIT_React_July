import React from 'react'
import './Styles.css'

function MyStyles(props) {
   const cssclass=props.status?'status-online':'status-offline'
  return (
    <div>
      <h1 className={cssclass}>Hello User...This is Sample Text</h1>
    </div>
  )
}

export default MyStyles