import React from 'react'

const mystyles={
    color:'orange',
    fontSize:'22px',
    backgroundColor:'cyan'
}
function InlineStyling() {
  return (
    <div>
        <p style={mystyles}>sample text here...</p>
    </div>
  )
}

export default InlineStyling