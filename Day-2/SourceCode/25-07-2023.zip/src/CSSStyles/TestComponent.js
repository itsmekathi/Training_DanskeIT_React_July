import React from 'react'
import styles from './appStyles.module.css'
import teststyles from './appStyles.module.css'

function TestComponent() {
  return (
    <div>
        <h1 className={styles.success}>Sample Text</h1>
        <h1 className={teststyles.error}>Sample Text</h1>
    </div>
  )
}

export default TestComponent