import React from 'react'

function Demo() {
   let str="i am From India"
   let str1="     india     "
   let MobPatt=new RegExp("[6-9]{1}[0-9]{9}")
   let mob="8000012345"
   let courses=["C","C++","Java","SQL"]

   let demoset=new Set()
   demoset.add(10)
   demoset.add(10)
   demoset.add(20)
   demoset.add(30)

   let courselist=new Map()
   courselist.set(1001,"C++")
   courselist.set(1001,"C#.NET")
   courselist.set(1002,"Java")
   courselist.set(1003,"Java")

   try{
        throw new Error("No Data Found!")
   }
   catch(err)
   {
        console.log("Error Occured")
   }

  return (
    <div>
       <h1>{str.length}</h1>
       <h1>{str.toUpperCase()}</h1>
       <h1>{str.toLowerCase()}</h1>
       <h1>{str.substring(3,8)}</h1>
       <h1>{str.replace('m','$')}</h1>
       <h1>{str.startsWith('i am')?'Yes':'No'}</h1>
       <h1>{str.endsWith('i am')?'Yes':'No'}</h1>
       <h1>{str.charAt(6)}</h1>
       <h1>{str.indexOf('m')}</h1>
       <h1>{str.lastIndexOf('m')}</h1>
       <h1>{str1.trimStart()}</h1>
       <h1>{str1.trimEnd()}</h1>
       <h1>{MobPatt.test(mob)?'Valid':'Invalid'}</h1>
       <h1>{courses[2]}</h1>
       <h1>{demoset}</h1>
       <h1>{courselist}</h1>
    </div>
  )
}

export default Demo