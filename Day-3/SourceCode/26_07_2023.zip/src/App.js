import logo from './logo.svg';
import './App.css';
import ParentComponent from './Components/LifeCycleEvents/ParentComponent';
import Table from './Components/Fragments/Table';
import RegularComponent from './Components/PureComponents/RegularComponent';
import DemoComponent from './Components/PureComponents/DemoComponent';
import NormalComponent from './Components/MemoComponents/NormalComponent';
import RefDemo from './Components/Refs/RefDemo';
import RefDemoFN from './Components/Refs/RefDemoFN';
import RefParent from './Components/ForwardRefs/RefParent';
import PortalsDemo from './Components/Portals/PortalsDemo';
import ProductComponent from './Components/ErrorHandling/ProductComponent';
import ErrorHandler from './Components/ErrorHandling/ErrorHandler';
import ErrorHandlerFN from './Components/ErrorHandling/ErrorHandlerFN';

function App() {
  return (
    <div className="App">
        {/* <ParentComponent/> */}
        {/* <Table/> */}
        {/* <RegularComponent/>
        <DemoComponent/> */}
        {/* <NormalComponent/> */}
        {/* <RefDemo/> */}
        {/* <RefDemoFN/> */}
        {/* <RefParent/>
        <PortalsDemo/> */}

         <ErrorHandler>
          <ProductComponent name="Iphone 14" category="Electronics"/>
        </ErrorHandler>

        <ErrorHandler>
          <ProductComponent name="Dell Laptop 6258" category="Electronics"/>
        </ErrorHandler>

          <ErrorHandler>
          <ProductComponent name="Audi" category="Automobiles"/>
        </ErrorHandler> *



        
    </div>
  );
}

export default App;
