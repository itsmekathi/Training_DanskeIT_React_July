import React from 'react'

function ChildComponentDemo(props) {
    console.log("------------Child Component-----------------")
  return (
    <div>
        ChildComponentDemo
        {props.name}
    </div>
  )
}

export default React.memo(ChildComponentDemo)