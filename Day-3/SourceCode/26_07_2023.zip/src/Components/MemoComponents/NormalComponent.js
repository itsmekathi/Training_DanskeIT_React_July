import React, { Component } from 'react'
import ChildComponentDemo from './ChildComponentDemo'

export class NormalComponent extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'test'
      }
    }
    componentDidMount()
    {
       setInterval(()=>{
        this.setState({name:'test'})
       },2000)
    }
  render() {
    console.log("------------Parent Component-----------------")
    return (
      <div>
        NormalComponent
        <ChildComponentDemo name={this.state.name}/>
      </div>
    )
  }
}

export default NormalComponent