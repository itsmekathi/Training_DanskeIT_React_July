import React from 'react'
import TableHead from './TableHead'
import TableBody from './TableBody'

function Table() {
  return (
    <div>
        <table border={"1"}>
            <TableHead/>
            <TableBody/>
        </table>
    </div>
  )
}

export default Table