import React from 'react'

function TableHead() {
  return (
    <React.Fragment>
        <thead>
            <tr>
                <th>Id</th>
                <th>Title</th>
            </tr>
        </thead>
    </React.Fragment>
  )
}

export default TableHead