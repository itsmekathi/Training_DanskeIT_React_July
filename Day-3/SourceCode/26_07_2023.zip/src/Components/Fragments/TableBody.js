import React from 'react'

function TableBody() {
  return (
    <React.Fragment>
        <tbody>
            <tr>
                <td>1</td>
                <td>Java</td>
            </tr>
            <tr>
                <td>2</td>
                <td>JavaScript</td>
            </tr>
            <tr>
                <td>3</td>
                <td>React</td>
            </tr>
        </tbody>
    </React.Fragment>
  )
}

export default TableBody