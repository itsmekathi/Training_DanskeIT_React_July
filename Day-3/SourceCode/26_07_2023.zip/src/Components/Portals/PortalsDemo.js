import React, { Component } from 'react'
import ReactDOM  from 'react-dom'

// function PortalsDemo() {
//   return ReactDOM.createPortal(
//     <div>
//         <h1>Welcome User</h1>
//         <marquee>This is a sample description</marquee>
//     </div>,document.getElementById('testdiv')
//   )
// }

class PortalsDemo extends Component
{
    render()
    {
        return ReactDOM.createPortal(
            <div>
                <h1>Welcome User</h1>
                <marquee>This is a sample description</marquee>
            </div>,document.getElementById('testdiv')
          )
    }
}

export default PortalsDemo