import React, {  PureComponent } from 'react'

export class DemoComponent extends PureComponent {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'Steve'
      }
    }
    componentDidMount()
    {
        setInterval(() => {
          this.setState({name:'Steve'})
        }, 2000);
    }
  render() {
    console.log("------------Pure Component--------------")
    return (
      <div>DemoComponent</div>
    )
  }
}

export default DemoComponent