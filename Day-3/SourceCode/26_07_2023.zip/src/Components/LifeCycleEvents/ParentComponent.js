import React, { Component } from 'react'
import ChildComponent from './ChildComponent'

export class ParentComponent extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'Guest'
      }

      console.log('------Parent Constuctor----------')
    }
    static getDerivedStateFromProps(props,state)
    {
        console.log('------Parent getDerivedStateFromProps----------')
        return null;
    }

    componentDidMount()
    {
        console.log('------Parent componentDidMount----------')
    }

    shouldComponentUpdate(nextProps,nextState)
    {
        console.log('------Parent shouldComponentUpdate----------')
        return true;
    }

    getSnapshotBeforeUpdate(prevProps,prevState)
    {
        console.log('------Parent getSnapshotBeforeUpdate----------')
        return null;
    }
    componentDidUpdate()
    {
        console.log('------Parent componentDidUpdate----------')
    }

   updatename=()=>
   {
     this.setState({name:'Admin'})
   }

  render() {
    console.log('------Parent render----------')
    return (
      <div>
        <h1>Parent Component</h1>
        <ChildComponent/>
        <button onClick={this.updatename}>Change Name</button>
      </div>
    )
  }
}

export default ParentComponent