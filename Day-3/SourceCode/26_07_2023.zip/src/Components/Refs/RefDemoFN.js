import React, { useEffect, useRef } from 'react'

function RefDemoFN() {
  const nameref=useRef()
    
  useEffect(()=>
  {
    nameref.current.placeholder="Enter Name Here"
    nameref.current.focus()
  })

  const clickhandler=()=>{
    alert(nameref.current.value)
  }
  return (    
    <div>
        <input type="text" id="txtName" name="txtName" ref={nameref}/>
        <br/>
        <button onClick={clickhandler}>Submit</button>
    </div>
  )
}

export default RefDemoFN