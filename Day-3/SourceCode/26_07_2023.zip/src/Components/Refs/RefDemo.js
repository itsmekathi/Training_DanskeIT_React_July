import React, { Component } from 'react'

export class RefDemo extends Component {
constructor(props) {
  super(props)
  this.nameref=React.createRef()
}
 componentDidMount()
 {
    //console.log(this.nameref.current)
    this.nameref.current.placeholder="Enter Name Here"
    this.nameref.current.focus();
    this.nameref.current.addEventListener('mouseover',this.test)
 }
 clickHandler=()=>{
    alert(this.nameref.current.value)
 }
 test=()=>{
    alert('DO some code')
 }
  render() {
    return (
      <div>
        <input type="text" id="txtname" name="txtname" ref={this.nameref}/>
        <br/>
        <button onClick={this.clickHandler}>Submit</button>
      </div>
    )
  }
}

export default RefDemo