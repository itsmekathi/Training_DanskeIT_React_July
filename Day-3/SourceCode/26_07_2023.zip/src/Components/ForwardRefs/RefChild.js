import React, { Component } from 'react'

// const RefChild=React.forwardRef((props,ref)=> {
//   return (
//     <div>
//         <input type="text" ref={ref}/>
//     </div>
//   )
// })

class RefChild extends Component{
   
    render()
    {
        return(
            <div>
                <input type="text" ref={this.props.forwaredRef}/>
            </div>
        )
    }
}

export default RefChild