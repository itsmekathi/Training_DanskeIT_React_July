import React, { Component } from 'react'
import RefChild from './RefChild'

export class RefParent extends Component {
    constructor(props) {
      super(props)
      this.nameref=React.createRef()
    }
    componentDidMount()
    {
        this.nameref.current.placeholder="Enter Name"
    }
    clickhandler=()=>{
        alert(this.nameref.current.value)
    }
  render() {
    return (
      <div>
        <RefChild forwaredRef={this.nameref}/>
        <button onClick={this.clickhandler}>Click Me</button>
      </div>
    )
  }
}

export default RefParent