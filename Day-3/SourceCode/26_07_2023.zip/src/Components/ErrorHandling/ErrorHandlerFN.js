import React from 'react'

function ErrorHandlerFN() {
  return (
    <div>ErrorHandlerFN</div>
  )
}

export default ErrorHandlerFN