import React from 'react'

// function Message() {
//   return (
//     <div>
//         <h1>Hello User... Welcome!</h1>
//         <h2>This is My First Component</h2>
//     </div>
//   )
// }

const Message=()=>
    <div>
        <h1>This is Sample Text</h1>
    </div>


export default Message