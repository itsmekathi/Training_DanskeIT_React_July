import React, { Component } from 'react'

export class Login extends Component {
    //rconst
   constructor(props) {
     super(props)
   
     this.state = {
       username:'Guest'
     }
   }

   changeusername(){
     this.setState({username:'Admin'})
   }
  render() {
    return (
      <div>
        <h1>Welcome,{this.state.username}</h1>
        <button onClick={()=>this.changeusername()}>Change User Name</button>
      </div>
    )
  }
}
export default Login