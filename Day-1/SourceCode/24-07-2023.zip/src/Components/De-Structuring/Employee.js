import React from 'react'

function Employee(props) {
    const{name,department}=props
  return (
    <div>
        <h1>
            Name:{name}
        </h1>
        <h2>
            Department:{department}
        </h2>
        <hr/>
    </div>
  )
}

export default Employee