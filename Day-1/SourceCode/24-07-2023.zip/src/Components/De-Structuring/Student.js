import React, { Component } from 'react'

export class Student extends Component {
  render() {
    const{name,classDetails} =this.props
    return (
      <div>
          <h1>Name:{name}</h1>
          <h2>Class:{classDetails}</h2>
          <hr/>
      </div>
    )
  }
}

export default Student