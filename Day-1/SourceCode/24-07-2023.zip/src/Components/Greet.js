import React from 'react'

function Greet(props) {
  return (
    <div>
        <h1>Message:{props.msg}</h1>
        <h2>From:{props.user}</h2>
        <p>{props.children}</p>
        <hr/>
    </div>
  )
}

// const Greet=(props)=>
// return()

export default Greet