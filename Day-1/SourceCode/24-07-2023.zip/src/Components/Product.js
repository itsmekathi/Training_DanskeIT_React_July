import React, { Component } from 'react'

export class Product extends Component {
  render() {
    return (
      <div>
        <h1>Name:{this.props.name}</h1>
        <h2>Price:{this.props.price}</h2>
        <p>{this.props.children}</p>
        <hr/>
      </div>
    )
  }
}

export default Product