import React, { Component } from 'react'

export class EventBinding04 extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         msg:'Good Afternoon!'
      }
    }
changemsg()
{
    console.log(this.state)
    this.setState({msg:'Good Evening!'})
}

  render() {
    return (
      <div>
        <p>{this.state.msg}</p>
        <button onClick={()=>this.changemsg()}>Change Message</button>
      </div>
    )
  }
}

export default EventBinding04