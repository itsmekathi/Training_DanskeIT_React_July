import React, { Component } from 'react'

export class EventBinding02 extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         msg:'Good Afternoon!'
      }
      this.changemsg=this.changemsg.bind(this)
    }
changemsg()
{
    console.log(this.state)
    this.setState({msg:'Good Evening!'})
}

  render() {
    return (
      <div>
        <p>{this.state.msg}</p>
        <button onClick={this.changemsg}>Change Message</button>
      </div>
    )
  }
}

export default EventBinding02