import React, { Component } from 'react'

export class EventBinding03 extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         msg:'Good Afternoon!'
      }
      
    }
changemsg()
{
    console.log(this.state)
    this.setState({msg:'Good Evening!'})
}

  render() {
    return (
      <div>
        <p>{this.state.msg}</p>
        <button onClick={this.changemsg.bind(this)}>Change Message</button>
      </div>
    )
  }
}

export default EventBinding03