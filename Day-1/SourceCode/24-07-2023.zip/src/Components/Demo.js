import React from 'react'

function Demo() {
//   return (
//     <div>
//         <h1>This is sample Heading</h1>
//         <p>This is sample Para</p>
//     </div>
//   )

return React.createElement('div',null,
[
    React.createElement('h1',{id:'sampleheading',className:'sample'},'This is sample Heading'),
    React.createElement('p',null,'This is sample Para')
]
)
}

export default Demo