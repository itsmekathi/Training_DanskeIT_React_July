import logo from './logo.svg';
import './App.css';
import Message from './Components/Message';
import Welcome from './Components/Welcome';
import Demo from './Components/Demo';
import Greet from './Components/Greet';
import Product from './Components/Product';
import Login from './Components/Login';
import EventBinding01 from './Components/EventBindings/EventBinding01';
import EventBinding02 from './Components/EventBindings/EventBinding02';
import EventBinding03 from './Components/EventBindings/EventBinding03';
import EventBinding04 from './Components/EventBindings/EventBinding04';
import Counter from './Components/SetState/Counter';
import Employee from './Components/De-Structuring/Employee';
import Student from './Components/De-Structuring/Student';

function App() {
  return (
    <div>
       {/* <Message/>
       <Welcome/>
       <Demo/> */}

       {/* <Greet msg="Happy Birth Day" user="Karthik">
          <p>Date:24-07-2023</p>
       </Greet>

       <Greet msg="Happy Birth Day" user="Krishna">
       <p>Date:24-07-2023</p>
       </Greet>

       <Greet msg="Happy Birth Day" user="Harry">
       <p>Date:24-07-2023</p>
       </Greet>

       <Greet msg="Happy Birth Day" user="Divya">
       <p>Date:24-07-2023</p>
       </Greet>


       <Product name="Iphone 14" price="85000">
          <p>Category:'Electronics'</p>
       </Product>

       <Product name="Iphone 13" price="65000">
          <p>Category:'Electronics'</p>
       </Product>

       <Product name="Iphone 12" price="59000">
       <p>Category:'Electronics'</p>
       </Product> */}

       {/* <Login/> */}

       {/* <EventBinding01/> */}

       {/* <EventBinding02/> */}
       {/* <EventBinding04/> */}
       {/* <Counter/> */}

       <Employee id="101" name="john" department="IT-Dev" salary="65000"/>
       <Employee id="102" name="krishna" department="IT-Support" salary="40000"/>
       <Employee id="103" name="raj" department="IT-Dev" salary="95000"/>


       <Student id="1" name="Jagan" classDetails="Class-IX" mobile="9848012345"/>
       <Student id="2" name="Prem" classDetails="Class-X" mobile="9849012345"/>
       <Student id="3" name="Kalyan" classDetails="Class-IX" mobile="8848012345"/>
       <Student id="4" name="Harry" classDetails="Class-X" mobile="7848012345"/>
       <Student id="5" name="Divya" classDetails="Class-X" mobile="9748012345"/>
    </div>
  );
}

export default App;
